# External service adapters
