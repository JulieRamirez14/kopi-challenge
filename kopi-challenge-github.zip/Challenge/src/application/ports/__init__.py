# Ports - Interfaces for external dependencies

from .conversation_repository import ConversationRepository

__all__ = [
    "ConversationRepository",
]